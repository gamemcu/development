local view=class()

function view:update()

end

return view
